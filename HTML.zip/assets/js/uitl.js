function connect_wallet(param) {
  console.log(param)
}
